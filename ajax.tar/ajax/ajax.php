<?php
include("sql.php"); 
pobierz($_GET["odPozycji"]);